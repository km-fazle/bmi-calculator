//
//  BMI.swift
//  BMI Calculator
//
//  Created by Faseeh Ahmed Khan Lodhi on 3/22/23.
//

import UIKit

struct BMI {
    let value: Float
    let adviceText: String
    let color: UIColor
    
}
